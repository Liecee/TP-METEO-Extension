export interface IListener {
  miseAJour(temperature: number, humidité: number): void;
}
